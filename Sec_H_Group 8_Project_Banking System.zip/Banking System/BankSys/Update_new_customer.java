
package BankSys;
import BankSys.*;

public class Update_new_customer extends AAdmin {
    
}
